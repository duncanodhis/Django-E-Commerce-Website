# Django E - Commerce Website

This Project is an E - commerce Website which is Built with Django and is Currently Deployed on My [Personal E - commerce website]

## Getting Started

First check all the You are having all the files including db.sqlite3 DataBase

### Prerequisites

Only Pre-Requiste is that you Install Python Interpreter.

### Installing

1. Open your Terminal in Linux or Mac and Command Prompt in Windows
2. Create a Virtual Enviroment by using a Command "virtualenv virtualenv". Your Virtual Enviroment has been created with the Name of virualenv
3. Now hit these command in Your Dezired Console 
	i) pip install django
	ii) pip install Pillow

## Running the tests

Fire up your Terminal and hit this Command:
1. python manage.py runserver

## Deployment

You can Depoly this Code but Be sure to change the DEBUG = False in settings.py file

## Built With

* Django
* Pillow

## Contributing

Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details on our code of conduct, and the process for submitting pull requests to us.

## Authors

* **Duncan Abonyo** - *Initial work* - [Duncan Abonyo](https://github.com/duncanodhis)

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE) file for details